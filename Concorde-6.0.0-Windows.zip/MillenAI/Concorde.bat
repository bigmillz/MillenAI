@echo off
setlocal
set "SUPPORT=%LOCALAPPDATA%\MillenAI"
set "VENV=%SUPPORT%\venv"
set "PY=%VENV%\Scripts\pythonw.exe"
set "PIP=%VENV%\Scripts\pip.exe"
if not exist "%SUPPORT%" mkdir "%SUPPORT%"

where python >nul 2>&1
if errorlevel 1 (
  echo Concorde needs Python 3.10 or newer.
  echo Install it from https://www.python.org/downloads/ ^(tick "Add to PATH"^)
  pause
  exit /b 1
)

if not exist "%PY%" (
  echo First run: setting up the AI engine. This takes a few minutes...
  python -m venv "%VENV%"
  "%PIP%" install --upgrade pip
  "%PIP%" install pywebview ddgs psutil faster-whisper
)

start "" "%PY%" "%~dp0millenai.py"
