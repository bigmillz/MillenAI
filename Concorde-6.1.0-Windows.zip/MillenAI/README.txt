Concorde 6.1.0 — local AI for Windows
=====================================

REQUIREMENTS
  * Windows 10/11, 64-bit
  * Python 3.10+ from python.org (tick "Add python.exe to PATH")
  * NVIDIA GPU recommended — see below.

INSTALL
  1. Unzip anywhere (e.g. Documents\Concorde)
  2. Double-click Concorde.bat
  3. First run installs the engine, then offers the models (~46 GB).
     SmartScreen may warn about an unknown publisher — choose
     "More info" then "Run anyway".

NVIDIA / CUDA
  Nothing to install and nothing to configure. Concorde downloads Ollama's
  Windows build, which bundles the CUDA runtime; Ollama detects the GPU and
  offloads to it on its own. Without an NVIDIA card everything still runs,
  just on the CPU and much slower.

WINDOWS ON ARM (Snapdragon / Surface / ARM VMs)
  Install the "Windows installer (64-bit)" — the x64 one, NOT ARM64.
  Two dependencies (pythonnet, which draws the window, and ctranslate2,
  which does voice input) ship x64 wheels only, so an ARM64 Python cannot
  install them. Windows 11 emulates the x64 build with no setup on your part.

  Only the app runs emulated — Concorde still fetches the native ARM64
  Ollama, so the models run at full speed. There is no CUDA on
  Windows-on-ARM, so inference is CPU-only on those machines.

Everything runs locally. No accounts, no cloud.
Models and settings live in %LOCALAPPDATA%\MillenAI
